package aula20180901.strategyMotor2;

public class Turbo implements Veneno {
	
	private double pressao;

	public Turbo(double pressao) {
		this.pressao = pressao;
	}

	@Override
	public double elevarPotencia(double potenciaInicial) {
		return potenciaInicial * ( pressao * 0.35);
	}
}
