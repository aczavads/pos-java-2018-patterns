package aula20180901.strategyMotor2;

public interface Veneno {

	double elevarPotencia(double potenciaInicial);
}
