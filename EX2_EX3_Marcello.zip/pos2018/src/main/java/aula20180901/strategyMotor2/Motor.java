package aula20180901.strategyMotor2;

import java.util.ArrayList;
import java.util.List;

public class Motor {
	private List<Veneno> veneno = new ArrayList<Veneno>();
	public final double POTENCIA_BASE = 100.00;

	public double produzirPotencia() {
		double potencia = 100.00;

		for (Veneno veneno : veneno) {
			potencia += veneno.elevarPotencia(POTENCIA_BASE);
		}
		return potencia;
	}

	public void turbinar() {
		this.turbinar(1.00);
	}

	public void turbinar(double pressao) {
		this.veneno.add(new Turbo(pressao));
	}

	public void chipar() {
		this.veneno.add(new Chip());
	}

	public void nitrar() {
		this.veneno.add(new Nitro());
	}
}
