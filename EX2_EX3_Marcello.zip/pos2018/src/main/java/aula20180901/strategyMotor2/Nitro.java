package aula20180901.strategyMotor2;

public class Nitro implements Veneno {

	@Override
	public double elevarPotencia(double potenciaInicial) {
		return potenciaInicial * 0.25;
	}

}
