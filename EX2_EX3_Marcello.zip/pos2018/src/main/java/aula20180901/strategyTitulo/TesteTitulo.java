package aula20180901.strategyTitulo;

import static org.junit.Assert.*;

import org.junit.Test;

public class TesteTitulo {

	@Test
	public void testeTituloEmDia() {
		Titulo t01 = new Titulo(100.00, 0);
		final double valorEsperado = 100.00;
		assertEquals(valorEsperado, t01.getValorComEncargos(), 0.00);
	}

	@Test
	public void testeTituloAtrasadoSemEncargos() {
		Titulo t01 = new Titulo(100.00, 5);
		final double valorEsperado = 100.00;
		assertEquals(valorEsperado, t01.getValorComEncargos(), 0.00);
	}

	@Test
	public void testeTituloComMulta() {
		Titulo t01 = new Titulo(100.00, 5, new Multa(10.00));
		final double valorEsperado = 110.00;
		assertEquals(valorEsperado, t01.getValorComEncargos(), 0.00);
	}

	@Test
	public void testeTituloComJuros() {
		Titulo t01 = new Titulo(100.00, 5, new Juros(1.00));
		final double valorEsperado = 105.00;
		assertEquals(valorEsperado, t01.getValorComEncargos(), 0.00);
	}

	@Test
	public void testeTituloComJurosMulta() {
		Titulo t01 = new Titulo(
				100.00,
				5,
				new CalculoDeEncargosComposto(new Juros(1.00), new Multa(10.00)));
		final double valorEsperado = 115.00;
		assertEquals(valorEsperado, t01.getValorComEncargos(), 0.00);
	}
}
