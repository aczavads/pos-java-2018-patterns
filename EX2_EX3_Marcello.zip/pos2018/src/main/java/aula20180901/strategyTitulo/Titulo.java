package aula20180901.strategyTitulo;

public class Titulo {

	private double valor;
	private int diasDeAtraso;
	private CalculoDeEncargo calculoDeEncargo = new NullCalculoDeEncargo();
	
	public Titulo(double valor, int diasDeAtraso) {
		this.valor = valor;
		this.diasDeAtraso = diasDeAtraso;
	}

	public Titulo(double valor, int diasDeAtraso, CalculoDeEncargo calculoDeEncargo) {
		this (valor, diasDeAtraso);
		this.calculoDeEncargo = calculoDeEncargo;
	}

	public double getValorComEncargos() {
		return valor + calculoDeEncargo.calcular(valor, diasDeAtraso);
	}

}
