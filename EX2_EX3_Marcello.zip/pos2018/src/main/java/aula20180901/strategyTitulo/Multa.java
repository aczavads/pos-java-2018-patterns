package aula20180901.strategyTitulo;

public class Multa implements CalculoDeEncargo{
	private double percentual;

	public Multa(double percentual) {
		this.percentual = percentual;
	}
	
	@Override
	public double calcular(double valorBase, int diasDeAtraso) {
		if (diasDeAtraso > 0) {
			return (percentual * valorBase / 100);
		}
		return valorBase;
	}
	
}
