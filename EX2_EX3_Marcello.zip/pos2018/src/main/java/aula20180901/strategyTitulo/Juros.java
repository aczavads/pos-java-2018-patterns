package aula20180901.strategyTitulo;

public class Juros implements CalculoDeEncargo{

	private double percentualPorDia;

	public Juros(double percentualPorDia) {
		this.percentualPorDia = percentualPorDia;
	}
	
	@Override
	public double calcular(double valorBase, int diasDeAtraso) {
		return percentualPorDia * diasDeAtraso;
	}
}
