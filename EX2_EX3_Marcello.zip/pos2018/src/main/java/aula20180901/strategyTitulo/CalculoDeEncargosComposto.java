package aula20180901.strategyTitulo;

import java.util.Arrays;

public class CalculoDeEncargosComposto implements CalculoDeEncargo {

	private CalculoDeEncargo[] calculos;

	public CalculoDeEncargosComposto(CalculoDeEncargo... calculos) {
	}

	@Override
	public double calcular(double valorBase, int diasDeAtraso) {
		double encargos = Arrays.stream(calculos).mapToDouble(c -> c.calcular(valorBase, diasDeAtraso)).sum();

		return encargos;
	}

}
