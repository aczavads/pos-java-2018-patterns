package aula20180901.strategyTitulo;

public class NullCalculoDeEncargo implements CalculoDeEncargo {

	@Override
	public double calcular(double valorBase, int diasDeAtraso) {
		return 0;
	}

}
