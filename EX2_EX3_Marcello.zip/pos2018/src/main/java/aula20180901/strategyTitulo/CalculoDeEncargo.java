package aula20180901.strategyTitulo;

public interface CalculoDeEncargo {

	double calcular(double valorBase, int diasDeAtraso);

}
