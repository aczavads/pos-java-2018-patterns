package aula20180901.strategyMotor;

public class Nitro implements Veneno {

	@Override
	public double elevarPotencia(double potenciaInicial) {
		// TODO Auto-generated method stub
		return 0;
	}

}
