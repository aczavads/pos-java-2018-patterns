package aula20180901.strategyMotor;

public class Motor {
	private boolean turbinado = false;
	private double pressaoDoTurbo = 1.00;
	private boolean nitrado = false;
	private boolean chipado = false;

	public double produzirPotencia() {
		double potenciaBase = 100.00;
		double potenciaFinal = potenciaTurbo(potenciaBase);
		potenciaFinal = potenciaNitro(potenciaFinal);
		potenciaFinal = potenciaChip(potenciaFinal);
		return potenciaFinal;
	}

	private double potenciaChip(double potenciaBase) {
		if (chipado)
			return potenciaBase + 25.00;
		else
			return potenciaBase;
	}

	private double potenciaNitro(double potenciaBase) {
		if (nitrado)
			return potenciaBase + 50.00;
		else
			return potenciaBase;
	}

	private double potenciaTurbo(double potenciaBase) {
		if (turbinado)
			return potenciaBase + (35.2 * pressaoDoTurbo);
		else
			return potenciaBase;
	}

	public void turbinar() {
		this.turbinar(1.00);
	}
	public void turbinar(double pressao) {
		this.turbinado = true;
		this.pressaoDoTurbo = pressao;
	}

	public boolean isTurbinado() {
		return turbinado;
	}

	public void chipar() {
		this.chipado = true;
	}

	public void nitrar() {
		this.nitrado = true;
	}

}
