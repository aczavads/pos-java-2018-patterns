package aula20180901.strategyMotor;

public class Chip implements Veneno{

	public double elevarPotencia(double potenciaInicial) {
		return 0;
	}

}
