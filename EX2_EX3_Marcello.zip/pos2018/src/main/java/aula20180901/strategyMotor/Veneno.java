package aula20180901.strategyMotor;

public interface Veneno {
	public double elevarPotencia(double potenciaInicial);

}
