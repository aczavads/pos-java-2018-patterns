package aula20180825.templateMethod.transacoes.base;

public abstract class Service {
	
	public final void excluirPeloId(int id) {
		iniciarTransação();
		executarExclusãoPeloId(id);
		efetivarTransação();
	}
	protected abstract void executarExclusãoPeloId(int id);
	
	public void iniciarTransação() {
		System.out.println("begin transaction");
	}
	public void efetivarTransação() {
		System.out.println("commit transaction");
	}


}
