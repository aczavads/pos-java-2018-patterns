package aula20180825.templateMethod.academico;

public class CálculoUniCesumar2018 extends CálculoResultadoAcadêmico {

	@Override
	public double calcularPercentualFaltas(RA ra, DisciplinaId disciplinaId,
			Bimestre bimestre) {
		return 25.01;
	}

	@Override
	public double calcularMédia(RA ra, DisciplinaId disciplinaId,
			Bimestre bimestre) {
		return 7;
	}

}
