package aula20180825.factory.loggerReflexivo;

public class XisLogger implements Logger {

	@Override
	public void error(String message) {
		System.out.println("xis!");
	}

	@Override
	public void info(String message) {
		System.out.println("xis!");
	}

	@Override
	public void warning(String message) {
		System.out.println("xis!");
	}

}
