package aula20180901.strategyTitulo;

public interface CalculoDeEncargo {
	public Double calcularValor(double valorBase, Integer diasAtraso);
}
