package aula20180901.strategyTitulo;

import java.io.ObjectInputStream.GetField;

public class Titulo {
	private Double valor;
	private Integer diasAtraso;	
	private CalculoDeEncargo calculo = new NullCalculoEncargo();

	public Titulo(Double valor, Integer diasAtraso) {
		this.valor = valor;
		this.diasAtraso = diasAtraso;		
	}
	
	public Titulo(Double valor, Integer diasAtraso, CalculoDeEncargo calculo) {
		this.valor = valor;
		this.diasAtraso = diasAtraso;
		this.calculo = calculo;
	}
	
	public Double getValorComEncargos(){
		return valor + calculo.calcularValor(this.valor, diasAtraso);
	}

}
