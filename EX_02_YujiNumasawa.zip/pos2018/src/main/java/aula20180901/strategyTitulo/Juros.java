package aula20180901.strategyTitulo;

public class Juros implements CalculoDeEncargo {	
	private Double percentualPorDia;	
	
	public Juros(Double percentual) {
		this.percentualPorDia = percentual;		
	}

	@Override
	public Double calcularValor(double valorBase, Integer diasAtraso) { 
		return valorBase * (percentualPorDia * diasAtraso);
	}

	

	
}
