package aula20180901.strategyMotor;

public class Chip implements Veneno{
	private double potenciaExtra = 0.25; 
	@Override
	
	public double elevarPotencia(Double potenciaInicial) {		
		return potenciaInicial * potenciaExtra;
	}

}
