package aula20180901.strategyMotor;

public class Nitro implements Veneno{
	private Double potenciaExtra = 0.50;
	
	@Override
	public double elevarPotencia(Double potenciaInicial) {		
		return potenciaInicial * potenciaExtra;
	}

}
