package aula20180901.strategyMotor;

public class Turbo implements Veneno{
	private Double nivelTurbo;
	private Double potenciaExtra = 0.35;

	public Turbo () {
		this.nivelTurbo = 1.00;		
	}
	
	public Turbo (double pressaoDoTurbo) {
		this.nivelTurbo = pressaoDoTurbo;		
	}
	
	@Override
	public double elevarPotencia(Double potenciaInicial) {		
		return potenciaInicial * (potenciaExtra * nivelTurbo);
	}

}
