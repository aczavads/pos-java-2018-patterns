package aula20180901.observerCartao;

import java.util.ArrayList;
import java.util.List;

public class CartaoDeCredito {	
	private List<CartaoDeCreditoListener> listener = new ArrayList<CartaoDeCreditoListener>();

	public void comprarAVista(Double valor) {
		System.out.println("Compra a Vista");
	}

	public void comprarAPrazo(Double valor, int quantidadeDeParcelas) {
		System.out.println("Compra a Prazo");
		for (CartaoDeCreditoListener cartaoDeCreditoListener : listener) {
			cartaoDeCreditoListener.compraParceladaRealziada(valor, quantidadeDeParcelas);			
		}
	}

	public void registrarListener(CartaoDeCreditoListener ccl) {
		listener.add(ccl);
	}

	public void removerListener(CartaoDeCreditoListener ccl) {
		listener.remove(ccl);
	}

}
