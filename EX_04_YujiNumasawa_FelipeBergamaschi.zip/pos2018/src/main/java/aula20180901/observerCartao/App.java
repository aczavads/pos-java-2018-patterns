package aula20180901.observerCartao;

public class App {
	public static void main(String[] args) {
		CartaoDeCreditoListener ccl = new CartaoCreditoListenerConsole();
		CartaoDeCredito cc = new CartaoDeCredito();
		cc.registrarListener(ccl);		
		cc.comprarAPrazo(200.00, 2);
		cc.removerListener(ccl);
		cc.comprarAPrazo(300.00, 3);
	}

}
