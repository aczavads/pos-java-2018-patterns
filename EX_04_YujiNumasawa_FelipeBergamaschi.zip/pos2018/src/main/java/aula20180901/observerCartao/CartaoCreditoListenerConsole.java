package aula20180901.observerCartao;

public class CartaoCreditoListenerConsole implements CartaoDeCreditoListener{

	@Override
	public void compraParceladaRealziada(double valor, int quantidadeDeParcelas) {
		System.out.println("Compra a prazo realizada! Valor: " + valor + " Parcelas: "+ quantidadeDeParcelas);
		
	}

}
