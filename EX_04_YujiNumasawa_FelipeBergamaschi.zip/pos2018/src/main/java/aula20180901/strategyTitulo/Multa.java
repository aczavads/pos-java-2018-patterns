package aula20180901.strategyTitulo;

public class Multa implements CalculoDeEncargo {
	private Double percentual;
		
	public Multa(Double percentual) {
		this.percentual = percentual;
	}

	@Override
	public Double calcularValor(double valorBase, Integer diasAtraso) {
		if (diasAtraso > 0) {
			return valorBase * percentual;
		}
		return null;
	}
}
