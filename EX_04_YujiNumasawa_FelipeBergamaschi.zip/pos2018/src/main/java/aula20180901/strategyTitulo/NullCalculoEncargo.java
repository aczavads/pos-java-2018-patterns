package aula20180901.strategyTitulo;

public class NullCalculoEncargo implements CalculoDeEncargo {

	@Override
	public Double calcularValor(double valorBase, Integer diasAtraso) {		
		return 0.00;
	}

}
