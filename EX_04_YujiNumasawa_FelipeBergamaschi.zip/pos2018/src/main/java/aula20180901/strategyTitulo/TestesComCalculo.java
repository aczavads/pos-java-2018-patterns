package aula20180901.strategyTitulo;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestesComCalculo {
	
	@Test
	public void testeTituloEmDia() {
		final double valorEsperado = 100.00;
		Titulo titulo = new Titulo(100.00, 0);
		assertEquals(valorEsperado, titulo.getValorComEncargos(), 0.00);
	}
	
	@Test
	public void testeTituloAtrasadoSemEncargos() {
		final double valorEsperado = 350.00;
		Titulo titulo = new Titulo(100.00, 5, new Juros(0.5));
		assertEquals(valorEsperado, titulo.getValorComEncargos(), 1.00);
	}
	
	@Test
	public void testeTituloAtrasadoComMulta() {
		final double valorEsperado = 1100.00;
		Titulo titulo = new Titulo(100.00, 1, new Multa(10.00));
		assertEquals(valorEsperado, titulo.getValorComEncargos(), 1.00);
	}
	
	@Test
	public void testeTituloAtrasadoComMultaEJuros() {
		final double valorEsperado = 1600.00;
		Titulo titulo = new Titulo(100.00, 5, new CalculoDeEncargosComposto(new Multa(10.00), new Juros(1.0)) );
		
		assertEquals(valorEsperado, titulo.getValorComEncargos(), 1.00);
	}

}
