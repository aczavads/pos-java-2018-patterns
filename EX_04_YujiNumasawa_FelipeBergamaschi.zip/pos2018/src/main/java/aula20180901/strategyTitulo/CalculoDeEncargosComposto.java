package aula20180901.strategyTitulo;

public class CalculoDeEncargosComposto implements CalculoDeEncargo{
	private CalculoDeEncargo[] calculos;

	public CalculoDeEncargosComposto(CalculoDeEncargo... calculos){
		this.calculos = calculos;
	}	

	@Override
	public Double calcularValor(double valorBase, Integer diasAtraso) {
		Double encargo = 0.00;
		for (CalculoDeEncargo calculoDeEncargo : calculos) {
			encargo += calculoDeEncargo.calcularValor(valorBase, diasAtraso);
		}
		return encargo;
	}
	
}
