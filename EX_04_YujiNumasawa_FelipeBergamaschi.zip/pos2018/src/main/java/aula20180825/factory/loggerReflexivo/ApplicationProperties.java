package aula20180825.factory.loggerReflexivo;

import java.io.InputStream;
import java.util.Properties;

public class ApplicationProperties {
	
	public static String getLoggerClassName() {
		try (InputStream input = ApplicationProperties.class
				.getResourceAsStream("application.properties")) {			
			
			Properties props = new Properties();
			props.load(input);
			String tipoDoLogger = props.getProperty("tipo.do.logger");
			return tipoDoLogger;
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
		return null;
	}

}
