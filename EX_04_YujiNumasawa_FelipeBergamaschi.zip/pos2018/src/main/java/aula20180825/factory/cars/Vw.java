package aula20180825.factory.cars;

public class Vw implements Montadora {

	@Override
	public Veiculo fabricar(String tipo) {
		switch (tipo) {
		case "hatch":
			return new Polo();
		case "sedan":
			return new Virtus();
		default:
			break;
		}
		return null;
	}

}
