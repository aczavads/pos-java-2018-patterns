package aula20180825.templateMethod.academico;

public class App {
	
	public static void main(String[] args) {
		CálculoResultadoAcadêmico cálculo = new CálculoUniCesumar2018();
		
		ResultadoAcadêmico resultado =  cálculo.calcular(
				new RA(50554,5), 
				new DisciplinaId(33), 
				new Bimestre(1));
		
		System.out.println(resultado);
	}

}
