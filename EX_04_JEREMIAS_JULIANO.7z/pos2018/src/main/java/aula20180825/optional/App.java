package aula20180825.optional;

import java.util.Optional;

public class App {
	
	public static void main(String[] args) {
		Optional<Pessoa> optPessoa = obterPessoa();
		System.out.println(optPessoa.orElse(new Pessoa("Não encontrada")).getNome());
		
		
	}

	private static Optional<Pessoa> obterPessoa() {
		if (System.currentTimeMillis()%2==0) {
			return Optional.empty();
		} 
		return Optional.of(new Pessoa("Fulano de Tal"));
	}

}

