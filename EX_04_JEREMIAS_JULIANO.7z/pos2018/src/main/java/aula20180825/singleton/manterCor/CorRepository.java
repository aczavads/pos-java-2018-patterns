package aula20180825.singleton.manterCor;

import java.util.UUID;

import aula20180825.singleton.ConnectionManager;

public class CorRepository {
	private ConnectionManager conn = null;
	
	
	public CorRepository(ConnectionManager conn) {
		this.conn = conn;
	}



	public void save(Cor c) {
		c.setId(UUID.randomUUID().toString());
		//ConnectionManager.getInstance().inserir(c);
		this.conn.inserir(c);
	}

}
