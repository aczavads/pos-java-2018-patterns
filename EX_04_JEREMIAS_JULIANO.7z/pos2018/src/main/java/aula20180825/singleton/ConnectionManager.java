package aula20180825.singleton;

public class ConnectionManager extends Object {
	private static ConnectionManager instance = null;
	
	private ConnectionManager() {
	}
	
	public static ConnectionManager getInstance() {
		/*
		 * se (objeto não existe) então
		 * 		crie o objeto
		 * fim se
		 * retorne o objeto
		 */
		if (instance == null) {
			instance = new ConnectionManager();
		}
		return instance;
	}
	
	public void inserir(Object obj) {
		if (System.currentTimeMillis()%2==0) {
			throw new RuntimeException("erro!");
		}
		System.out.println("Inserindo no banco os dados do objeto: " + obj);
	}

}
