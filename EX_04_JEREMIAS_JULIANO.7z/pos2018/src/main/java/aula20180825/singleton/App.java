package aula20180825.singleton;

import aula20180825.singleton.manterCor.Cor;
import aula20180825.singleton.manterCor.CorRepository;

public class App {
	
	public static void main(String[] args) {
		
		//ConnectionManager cm = new ConnectionManager();
		ConnectionManager cm = ConnectionManager.getInstance();
		ConnectionManager cm1 = ConnectionManager.getInstance();
		
		
		
		System.out.println(cm);
		System.out.println(cm1);
		
		Cor c = new Cor("Amarelo");
		CorRepository repo = new CorRepository(cm);
		repo.save(c);
		
	}

}
