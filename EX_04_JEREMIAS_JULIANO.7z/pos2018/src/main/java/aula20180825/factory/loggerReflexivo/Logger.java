package aula20180825.factory.loggerReflexivo;

public interface Logger {
	
	void error(String message);
	void info(String message);
	void warning(String message);

}
