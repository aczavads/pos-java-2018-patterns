package aula20180825.factory.loggerReflexivo;

import javax.swing.JOptionPane;

public class GUILogger implements Logger {

	@Override
	public void error(String message) {
		JOptionPane.showMessageDialog(null, "ERROR: " + message);
	}

	@Override
	public void info(String message) {
		JOptionPane.showMessageDialog(null, "INFO: " + message);
	}

	@Override
	public void warning(String message) {
		JOptionPane.showMessageDialog(null, "WARNING: " + message);
	}

}
