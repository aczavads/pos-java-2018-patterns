package aula20180825.factory.loggerReflexivo;

public class ConsolePlusLogger implements Logger {

	@Override
	public void error(String message) {
		System.out.println("PLUS:error    => " + message);
	}

	@Override
	public void info(String message) {
		System.out.println("PLUS:info     => " + message);
	}

	@Override
	public void warning(String message) {
		System.out.println("PLUS:warning  => " + message);
	}

}
