package aula20180825.factory.cars;

public interface Montadora {
	
	Veiculo fabricar(String tipo);
	
	public static Montadora criarMontadora() {
		if (System.currentTimeMillis()%2==0) {
			return new Fiat();
		} 
		return new Vw();
	}

}
