package aula20180825.factory.cars;

public class Cronos implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Vrrummm.... cronos!");
	}

	@Override
	public void desligar() {
		System.out.println("Cleq cleq.... cronos!");
	}

}
