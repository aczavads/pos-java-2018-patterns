package aula20180825.factory.cars;

public class Polo implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Polo ligado!");
	}

	@Override
	public void desligar() {
		System.out.println("Polo desligado!");

	}

}
