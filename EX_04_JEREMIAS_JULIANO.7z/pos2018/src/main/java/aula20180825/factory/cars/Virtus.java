package aula20180825.factory.cars;

public class Virtus implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Virtus on.");
	}

	@Override
	public void desligar() {
		System.out.println("Virtus off.");
	}

}
