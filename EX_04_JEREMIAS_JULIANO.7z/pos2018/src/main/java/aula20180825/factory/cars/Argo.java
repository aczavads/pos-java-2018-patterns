package aula20180825.factory.cars;

public class Argo implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Argo ligando.");
	}

	@Override
	public void desligar() {
		System.out.println("Argo desligando.");
	}

}
