package aula20180825.factory.cars;

public interface Veiculo {
	
	void ligar();
	void desligar();

}
