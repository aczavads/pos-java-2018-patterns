package aula20180825.factory.cars;

public class Fiat implements Montadora {

	@Override
	public Veiculo fabricar(String tipo) {
		switch (tipo) {
		case "hatch":
			return new Argo();
		case "sedan":
			return new Cronos();
		default:
			break;
		}
		return null;
	}

}
