package aula20180825.factory.loggerConfigExterna;


public class App {
	
	public static void main(String[] args) {
		//Connection conn = DriverManager.getConnection("jdbc:h2:file:~/teste", "sa", "");
		//Logger logger = LoggerFactory.createLogger(LoggerType.NULL);		
		
		Logger logger = LoggerFactory.createLogger(ApplicationProperties.getLoggerType());

		logger.info("Iniciando processo...");
		try {
			for (int i = 0; i < 10; i++) {
				Thread.sleep(500);
				logger.info("Processando...");
				long valor = (long)(999 / (System.currentTimeMillis()%2));
			}
			logger.info("Processo concluído!");
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
	}

}
