package aula20180825.factory.loggerConfigExterna;

public enum LoggerType {
	CONSOLE, GUI, NULL, CONSOLE_PLUS

}
