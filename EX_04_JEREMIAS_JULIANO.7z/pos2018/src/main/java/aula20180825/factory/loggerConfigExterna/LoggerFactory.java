package aula20180825.factory.loggerConfigExterna;

public abstract class LoggerFactory {

	public static Logger createLogger(LoggerType type) {
		
		switch (type) {
		case CONSOLE: 
			return new ConsoleLogger();
		case GUI: 
			return new GUILogger();
		case CONSOLE_PLUS: 
			return new ConsolePlusLogger();
		default:
			
			//return null;
			//throw new RuntimeException("Logger deve ser definido!");
			return new NullLogger();
		}
		
	}

}
