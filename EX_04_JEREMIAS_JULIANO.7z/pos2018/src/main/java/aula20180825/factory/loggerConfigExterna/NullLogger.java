package aula20180825.factory.loggerConfigExterna;

public class NullLogger implements Logger {

	@Override
	public void error(String message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void info(String message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void warning(String message) {
		// TODO Auto-generated method stub

	}

}
