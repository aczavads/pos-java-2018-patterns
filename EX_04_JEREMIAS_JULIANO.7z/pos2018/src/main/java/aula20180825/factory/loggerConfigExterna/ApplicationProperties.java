package aula20180825.factory.loggerConfigExterna;

import java.io.InputStream;
import java.util.Properties;

public class ApplicationProperties {
	
	public static LoggerType getLoggerType() {
		try (InputStream input = ApplicationProperties.class
				.getResourceAsStream("application.properties")) {			
			
			Properties props = new Properties();
			props.load(input);
			String tipoDoLogger = props.getProperty("tipo.do.logger");
			return LoggerType.valueOf(tipoDoLogger);
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
		return null;
	}

}
