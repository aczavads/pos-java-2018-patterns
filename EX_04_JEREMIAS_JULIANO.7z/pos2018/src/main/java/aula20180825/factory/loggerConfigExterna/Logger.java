package aula20180825.factory.loggerConfigExterna;

public interface Logger {
	
	void error(String message);
	void info(String message);
	void warning(String message);

}
