package aula20180825.factory.logger;

public enum LoggerType {
	CONSOLE, GUI, NULL

}
