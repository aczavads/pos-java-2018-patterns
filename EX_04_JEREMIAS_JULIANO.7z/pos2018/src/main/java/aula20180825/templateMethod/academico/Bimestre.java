package aula20180825.templateMethod.academico;

 public class Bimestre {

	private int número;

	public Bimestre(int número) {
		this.número = número;
	}

}
