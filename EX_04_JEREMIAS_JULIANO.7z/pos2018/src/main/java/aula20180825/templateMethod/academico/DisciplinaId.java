package aula20180825.templateMethod.academico;

public class DisciplinaId {

	private int valor;

	public DisciplinaId(int valor) {
		this.valor = valor;
	}
	
	

}
