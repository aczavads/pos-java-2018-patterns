package aula20180825.templateMethod.academico;

public enum ResultadoAcadêmico {
	APROVADO, REPROVADO_POR_NOTA, REPROVADO_POR_FALTAS, REPROVADO

}
