package aula20180825.templateMethod.academico;

public class RA {
	private int número;
	private int dígito;

	public RA(int número, int dígito) {
		this.número = número;
		this.dígito = dígito;
	}

}
