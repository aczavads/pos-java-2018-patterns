package aula20180825.templateMethod.academico;

public abstract class CálculoResultadoAcadêmico {

	public ResultadoAcadêmico calcular(RA ra, DisciplinaId disciplinaId, Bimestre bimestre) {
		double média = calcularMédia(ra, disciplinaId, bimestre);
		double percentualDefaltas = calcularPercentualFaltas(ra, disciplinaId, bimestre);
		
		if (reprovado(média, percentualDefaltas)) {
			return ResultadoAcadêmico.REPROVADO;
		}
		if (reprovadoPorFaltas(média, percentualDefaltas)) {
			return ResultadoAcadêmico.REPROVADO_POR_FALTAS;
		}
		if (reprovadoPorNota(média, percentualDefaltas)) {
			return ResultadoAcadêmico.REPROVADO_POR_NOTA; 
		}		
		return ResultadoAcadêmico.APROVADO;
	}

	private boolean reprovadoPorNota(double média, double percentualDefaltas) {
		return média < 6 && percentualDefaltas < 25;
	}

	private boolean reprovadoPorFaltas(double média, double percentualDefaltas) {
		return média > 6 && percentualDefaltas > 25;
	}

	private boolean reprovado(double média, double percentualDefaltas) {
		return média < 6 && percentualDefaltas > 25;
	}

	public abstract double calcularPercentualFaltas(RA ra, DisciplinaId disciplinaId, Bimestre bimestre);
	public abstract double calcularMédia(RA ra, DisciplinaId disciplinaId, Bimestre bimestre);
}
