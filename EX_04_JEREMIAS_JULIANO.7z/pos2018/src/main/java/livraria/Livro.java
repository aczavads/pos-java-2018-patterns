package livraria;

public class Livro {
	// - titulo : String
	public final Titulo titulo;

	// - numeroDePaginas : int
	public final NumeroDePaginas numeroDePaginas;

	// + Livro(titulo : String, numeroDePaginas : int)
	public Livro(Titulo titulo, NumeroDePaginas numeroDePaginas) {
		this.titulo = titulo;
		this.numeroDePaginas = numeroDePaginas;
	}

}
