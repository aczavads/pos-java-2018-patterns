package livraria;

public class NumeroDePaginas {
	public final int valor;

	public NumeroDePaginas(int valor) {
		if (valor <= 0) {
			throw new RuntimeException("N�mero de p�ginas deve ser maior que zero!");
		}		
		this.valor = valor;
	}
	
	

}
