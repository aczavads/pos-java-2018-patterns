package livraria;

public class Titulo {
	public final String valor;

	public Titulo(String valor) {
		if (valor == null || valor.trim().length() < 3) {
			throw new RuntimeException("T�tulo deve ter 3 ou mais caracteres!");
		}		
		this.valor = valor;
	}
}
