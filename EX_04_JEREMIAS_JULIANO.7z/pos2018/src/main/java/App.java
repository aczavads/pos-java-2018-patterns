import livraria.Autor;
import livraria.Livro;
import livraria.NumeroDePaginas;
import livraria.Titulo;


public class App {
	
	public static void main(String[] args) {
		Livro bigJava;  //declara��o da vari�vel bigJava
		bigJava = new Livro(new Titulo("Big Java Edi��o Ouro"),new NumeroDePaginas(882)); //instanciar objeto e atribuir � vari�vel
		
		System.out.println(bigJava.titulo);
		
		Livro novo = new Livro(new Titulo("Novo"), new NumeroDePaginas(43));
		
		Autor horstmann = new Autor();
		horstmann = new Autor();
	}

}
