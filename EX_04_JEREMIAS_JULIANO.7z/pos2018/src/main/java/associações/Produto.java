package associações;

public class Produto {
	private String nome;
	
	public Produto(String nome) {
		this.nome = nome;
	}	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

}
