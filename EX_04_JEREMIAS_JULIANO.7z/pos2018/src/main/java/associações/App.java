package associações;

import associações.Pedido.ItemPedido;

public class App {
	
	public static void main(String[] args) {
		Produto fraldaPampersG = new Produto("Fralda Pampers Confort Sec G");
		Produto hidratanteDoveBaby = new Produto("Hidratante Dove Baby");
		
		Pedido p1 = new Pedido(1);
		
		//ItemPedido ip1 = new ItemPedido(fraldaPampersG, 3, 139.90);
		ItemPedido ip1 = p1.adicionarItem(fraldaPampersG, 3, 139.90);
		ItemPedido ip2 = p1.adicionarItem(hidratanteDoveBaby, 5, 7.99);
		//ItemPedido ip3 = p1.adicionarItem(hidratanteDoveBaby, 5, 7.99);
		
		System.out.println("Total do pedido: " + p1.getTotal());
		
		
	}

}
