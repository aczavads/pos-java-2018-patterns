package associações;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
	private int número;
	private List<ItemPedido> itens = new ArrayList<Pedido.ItemPedido>();
		
	public Pedido(int número) {
		this.número = número;
	}
	
	public int getNúmero() {
		return número;
	}
	
	public void setNúmero(int número) {
		this.número = número;
	}
	
	//+ adicionarItem(produto : Produto, quantidade : double, preço : double) : ItemPedido
	public ItemPedido adicionarItem(Produto produto, double quantidade, double preço) {
		boolean achou = this.itens.stream().parallel().filter(ip -> ip.getProduto().equals(produto)).count() > 0;
		if (achou) {
			throw new RuntimeException("Produtos duplicados não são permitidos no mesmo pedido!");
		}
//		for (ItemPedido itemPedido : itens) {
//			if (itemPedido.getProduto().equals(produto)) {
//				throw new RuntimeException("Produtos duplicados não são permitidos no mesmo pedido!");
//			}
//		}
		ItemPedido novo = new ItemPedido(produto, quantidade, preço);
		itens.add(novo);
		return novo;
	}
	
	public double getTotal() {
		/*
		double total = 0.00;
		for (ItemPedido item : itens) {
			total += item.quantidade*item.preço;
		}
		return total;
		*/
		return this.itens.stream().parallel()
				.map(ip -> ip.getQuantidade()*ip.getPreço())
				.reduce((total, atual) -> total+atual).get();
	}
	
	
	
	public static class ItemPedido {
		private Produto produto;
		private double quantidade;
		private double preço;
		
		private ItemPedido(Produto produto, double quantidade, double preço) {
			this.produto = produto;
			this.quantidade = quantidade;
			this.preço = preço;
		}
		public Produto getProduto() {
			return produto;
		}
		public void setProduto(Produto produto) {
			this.produto = produto;
		}
		public double getQuantidade() {
			return quantidade;
		}
		public void setQuantidade(double quantidade) {
			this.quantidade = quantidade;
		}
		public double getPreço() {
			return preço;
		}
		public void setPreço(double preço) {
			this.preço = preço;
		}
	}


}



