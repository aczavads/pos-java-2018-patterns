package aula20180901.strategyMotor;

public class Chip implements Veneno{
	@Override
	public double elevarPotencia(double potenciaBase){
		return potenciaBase * 0.25;
	}
}
