package aula20180901.strategyMotor;

public class Turbo implements Veneno{
	private double pressaoDoTurbo;
	
	public Turbo() {
		this.pressaoDoTurbo = 1.00;
	}
	
	public Turbo(double pressaoDoTurbo) {
		this.pressaoDoTurbo = pressaoDoTurbo;
	}
	
	@Override
	public double elevarPotencia(double potenciaBase){
		return potenciaBase * (0.35 * pressaoDoTurbo);
	}
}
