package aula20180901.strategyMotor;

import java.util.ArrayList;
import java.util.List;

public class Motor {
	private List<Veneno> venenos = new ArrayList<Veneno>();
	
	public double produzirPotencia() {
		double potenciaFinal = elevarPotencia(100.00);
		
		return potenciaFinal;
	}

	public void chipar() {
		venenos.add(new Chip());
	}

	public void nitrar() {
		venenos.add(new Nitro());
	}
	
	public void turbinar() {
		venenos.add(new Turbo());
	}
	
	public void turbinar(double pressao) {
		venenos.add(new Turbo(pressao));
	}
	
	public double elevarPotencia(double potenciaBase){
		double potencia = potenciaBase;
		
		for (Veneno item : venenos) {
			potencia += item.elevarPotencia(potenciaBase);
		}
		
		return potencia;
	}

}
