package aula20180901.strategyMotor;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestesComMotor {

	@Test
	public void testarPotenciaDoMotor() {
		Motor m01 = new Motor();
		final double potenciaEsperada = 100.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}
	@Test
	public void testarPotenciaDoMotorTurbinado() {
		Motor m01 = new Motor();
		m01.turbinar();
		final double potenciaEsperada = 135.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}
	@Test
	public void testarPotenciaDoMotorTurbinado2() {
		Motor m01 = new Motor();
		m01.turbinar(2.00);
		final double potenciaEsperada = 170.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}
	@Test
	public void testarPotenciaDoMotorTurbinado3() {
		Motor m01 = new Motor();
		m01.turbinar(3.00);
		final double potenciaEsperada = 205.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}
	@Test
	public void testarPotenciaDoMotorChipado() {
		Motor m01 = new Motor();
		m01.chipar();
		final double potenciaEsperada = 125.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}
	@Test
	public void testarPotenciaDoMotorNitrado() {
		Motor m01 = new Motor();
		m01.nitrar();
		final double potenciaEsperada = 150.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}
	@Test
	public void testarPotenciaDoMotorTubinadoNitrado() {
		Motor m01 = new Motor();
		m01.nitrar();
		m01.turbinar();
		final double potenciaEsperada = 185.00;
		
		assertEquals(potenciaEsperada, m01.produzirPotencia(), 1.00);
	}

}
