package aula20180901.strategyMotor;

public interface Veneno {
	double elevarPotencia(double potenciaBase);
}
