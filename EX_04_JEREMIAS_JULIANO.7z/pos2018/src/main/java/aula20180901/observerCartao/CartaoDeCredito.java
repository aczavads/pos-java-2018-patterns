package aula20180901.observerCartao;

import java.util.ArrayList;
import java.util.List;

public class CartaoDeCredito {

	private List<CartaoDeCreditoListener> cartaoDeCreditoListener = new ArrayList<CartaoDeCreditoListener>();
	
	public void comprarAVista(double valor){
		
	}
	
	public void comprarParcelado(double valor, int numeroDeParcelas){
		for (CartaoDeCreditoListener item : cartaoDeCreditoListener) {
			item.compraParceladaRealizada(valor, numeroDeParcelas);	
		}
	}
	
	public void registarListener(CartaoDeCreditoListener cartaoDeCreditoListener){
		this.cartaoDeCreditoListener.add(cartaoDeCreditoListener);
	}
	
	public void removerListener(){
		for (CartaoDeCreditoListener item : cartaoDeCreditoListener) {
			this.cartaoDeCreditoListener.remove(item);	
		}
		
	}
}
