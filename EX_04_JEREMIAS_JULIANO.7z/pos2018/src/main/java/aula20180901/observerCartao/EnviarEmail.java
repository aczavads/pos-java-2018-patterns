package aula20180901.observerCartao;

public class EnviarEmail implements CartaoDeCreditoListener{

	@Override
	public void compraParceladaRealizada(double valor, int numeroDeParcelas){
		System.out.println("Compra parcelada realizada. Enviando e-mail...");
	}
}
