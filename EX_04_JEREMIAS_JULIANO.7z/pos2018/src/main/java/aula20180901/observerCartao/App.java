package aula20180901.observerCartao;

public class App {
	public static void main(String[] args) {
		CartaoDeCredito meuCartao = new CartaoDeCredito();
		
		meuCartao.comprarAVista(10);
		
		meuCartao.registarListener(new EnviarEmail());
		meuCartao.registarListener(new EnviarSMS());
		
		meuCartao.comprarParcelado(30, 2);
		
		meuCartao.removerListener();
		
		meuCartao.comprarParcelado(60, 3);
		
		meuCartao.registarListener(new EnviarMensagemWpp());
	}
}
