package aula20180901.observerCartao;

import static org.junit.Assert.*;

import org.junit.Test;

public class TesteCartaoDeCredito {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
