package aula20180901.strategyTitulo;

public interface CalculoEncargo {
	double calcularEncargo(double valor, int diasAtraso);
}
