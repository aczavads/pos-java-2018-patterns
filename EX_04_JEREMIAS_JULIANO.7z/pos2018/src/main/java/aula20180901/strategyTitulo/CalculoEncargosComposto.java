package aula20180901.strategyTitulo;

public class CalculoEncargosComposto implements CalculoEncargo{

	private CalculoEncargo[] encargos; 
	
	public CalculoEncargosComposto(CalculoEncargo... encargos){
		this.encargos = encargos;
	}
	
	@Override
	public double calcularEncargo(double valor, int diasAtraso){
		return valor;
	}
}
