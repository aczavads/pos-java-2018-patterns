package aula20180901.strategyTitulo;

public class Multa implements CalculoEncargo{
	private double percentual;
	
	public Multa(double percentual){
		this.percentual = percentual;
	}
	
	@Override
	public double calcularEncargo(double valor, int diasAtraso){
		return (percentual * (valor / 100));
	}
}
