package aula20180901.strategyTitulo;

public class NullCalculoEncargo implements CalculoEncargo{

	@Override
	public double calcularEncargo(double valor, int diasAtraso){
		return valor;
	}
}