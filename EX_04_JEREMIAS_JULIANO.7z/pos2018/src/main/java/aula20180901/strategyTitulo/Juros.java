package aula20180901.strategyTitulo;

public class Juros implements CalculoEncargo{
	private double percentual;

	public Juros(double percentual){
		this.percentual = percentual;
	}
	
	@Override
	public double calcularEncargo(double valor, int diasAtraso){
		return (diasAtraso * (percentual * (valor / 100)));
	}
}
