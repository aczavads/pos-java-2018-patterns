package aula20180901.strategyTitulo;

public class Titulo {
	public double valor;
	public int diasAtraso;
	
	private CalculoEncargo calculoEncargo = new NullCalculoEncargo();
	
	public Titulo(double valor, int diasAtraso){
		this.valor = valor;
		this.diasAtraso = diasAtraso;
	}
	
	public Titulo(double valor, int diasAtraso, CalculoEncargo CalculoEncargo){
		this.valor = valor;
		this.diasAtraso = diasAtraso;
		this.calculoEncargo = CalculoEncargo;
	}
	
	public Titulo(double valor, int diasAtraso, CalculoEncargosComposto encargos){
		this.valor = valor;
		this.diasAtraso = diasAtraso;
		this.calculoEncargo = encargos;
		
	}
	
	public double getValorAtual(){
		return this.valor + calculoEncargo.calcularEncargo(valor, diasAtraso);
	}
	
}
