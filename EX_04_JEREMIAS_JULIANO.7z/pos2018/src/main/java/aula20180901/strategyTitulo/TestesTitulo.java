package aula20180901.strategyTitulo;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestesTitulo {
	private static double VALOR_TITULO = 100.00;
	
	@Test
	public void testarTituloEmDia() {
		Titulo titulo = new Titulo(VALOR_TITULO, 0);
		
		assertEquals(100.00, titulo.getValorAtual(), 1.00);
	}
	
	@Test
	public void testarTituloComMulta() {
		Titulo titulo = new Titulo(VALOR_TITULO, 1, new Multa(5));
		
		assertEquals(105.00, titulo.getValorAtual(), 1.00);
	}
	
	@Test
	public void testarTituloComJuros() {
		Titulo titulo = new Titulo(VALOR_TITULO, 3, new Juros(4.5));
		
		assertEquals(113.50, titulo.getValorAtual(), 1.00);
	}
	
	@Test
	public void testarTituloComMultaJuros() {
		Titulo titulo = new Titulo(VALOR_TITULO, 5, new CalculoEncargosComposto(new Multa(2.5), new Juros(3.5)));
		
		assertEquals(120.00, titulo.getValorAtual(), 1.00);
	}
}
