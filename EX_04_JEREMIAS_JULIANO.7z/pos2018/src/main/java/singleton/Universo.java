package singleton;

public class Universo {
	private static Universo o_único_inexorável_universo = null;
	
	public static Universo getUniverso() {
		if (o_único_inexorável_universo == null) {
			System.out.println("Lá se vão seis dias... :D");
			o_único_inexorável_universo = new Universo();
		}
		return o_único_inexorável_universo;
	}
	
	private Universo() {
	}

}
