package aula20180825.abstractFactory.exercicio01;

public class Fiat implements FabricanteCarro{

	@Override
	public Veiculo fabricar(String Tipo) {
		switch (Tipo) {
		case "hatch":
			return new Palio();
		case "sedan":
			return new Siena();
		case "SUV":
			return new Toro();		
		}
		return null;
	}
	
}
