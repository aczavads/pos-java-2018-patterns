package aula20180825.abstractFactory.exercicio01;

public interface FabricanteCarro {
	Veiculo fabricar(String Tipo);
	
	public static FabricanteCarro criarFabricante(){
		if (System.currentTimeMillis()%2==0) {
			return new Fiat();
		}
		return new Ford();				
	};
}
