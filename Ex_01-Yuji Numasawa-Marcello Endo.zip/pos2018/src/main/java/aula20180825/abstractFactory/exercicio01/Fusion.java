package aula20180825.abstractFactory.exercicio01;

public class Fusion implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Ligando Fusion...");

	}

	@Override
	public void desligar() {
		System.out.println("Desligando Fusion...");

	}

}
