package aula20180825.abstractFactory.exercicio01;

public class Ford implements FabricanteCarro{

	@Override
	public Veiculo fabricar(String Tipo) {
		switch (Tipo) {
		case "hatch":
			return new Fiesta();
		case "sedan":
			return new Fusion();
		case "SUV":
			return new Ranger();		
		}
		return null;
	}
	
}
