package aula20180825.abstractFactory.exercicio01;

public interface Veiculo {
	void ligar();
	void desligar();
}
