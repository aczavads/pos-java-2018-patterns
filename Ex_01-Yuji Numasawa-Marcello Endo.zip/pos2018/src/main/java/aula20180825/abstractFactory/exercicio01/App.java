package aula20180825.abstractFactory.exercicio01;

public class App {
	public static void main(String[] args) {
		FabricanteCarro fc = FabricanteCarro.criarFabricante();
		Veiculo hatch = fc.fabricar("hatch");
		
		hatch.ligar();
		hatch.desligar();
	}
}
