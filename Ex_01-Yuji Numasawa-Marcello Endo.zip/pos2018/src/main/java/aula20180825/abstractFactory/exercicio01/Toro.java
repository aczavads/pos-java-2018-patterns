package aula20180825.abstractFactory.exercicio01;

public class Toro implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Ligando tORO...");

	}

	@Override
	public void desligar() {
		System.out.println("Desligando tORO...");

	}

}
