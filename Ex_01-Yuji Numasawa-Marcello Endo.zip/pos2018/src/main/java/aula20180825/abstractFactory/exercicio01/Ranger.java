package aula20180825.abstractFactory.exercicio01;

public class Ranger implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Ligando Ranger...");

	}

	@Override
	public void desligar() {
		System.out.println("Desligando Ranger...");
	}

}
