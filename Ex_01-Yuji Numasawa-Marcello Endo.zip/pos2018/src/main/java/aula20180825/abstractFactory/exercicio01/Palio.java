package aula20180825.abstractFactory.exercicio01;

public class Palio implements Veiculo {

	@Override
	public void ligar() {
		System.out.println("Palio...");	
	}

	@Override
	public void desligar() {
		System.out.println("Desligando Palio");
	}

}
