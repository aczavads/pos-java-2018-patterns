package aula20180825.factory.logger;

public interface Logger {
	
	void error(String message);
	void info(String message);
	void warning(String message);

}
