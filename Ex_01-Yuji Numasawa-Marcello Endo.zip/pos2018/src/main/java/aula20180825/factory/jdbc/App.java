package aula20180825.factory.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class App {

	public static void main(String[] args) {

		try {
			Connection conn1 = DriverManager.getConnection(
					"jdbc:h2:file:~/teste", "sa", "");
			
			Connection conn2 = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/postgres", "postgres", "unicesumar");
			
			//org.h2.tools.Server.startWebServer(conn);
			
			System.out.println("Opa, conectado!");
			System.out.println(conn1.getClass());
			System.out.println(conn2.getClass());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
