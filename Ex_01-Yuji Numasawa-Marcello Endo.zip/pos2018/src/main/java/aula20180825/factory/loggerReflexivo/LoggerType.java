package aula20180825.factory.loggerReflexivo;

public enum LoggerType {
	CONSOLE, GUI, NULL, CONSOLE_PLUS

}
