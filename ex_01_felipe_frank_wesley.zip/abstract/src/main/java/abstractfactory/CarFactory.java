package abstractfactory;

public abstract class CarFactory {

	public static CarFactory getFactory(FactoryType type) {
		switch (type) {
		case BMW:
			return new BMWFactory();
		case VOLVO:
			return new VolvoFactory();
		default:
			return null;
		}
		
	}

	public abstract Car buildCar(CarType type);
	
}
