package abstractfactory;

public class SUVVolvo implements SUV {

	@Override
	public String getName() {
		return "SUV da Volvo";
	}

}
