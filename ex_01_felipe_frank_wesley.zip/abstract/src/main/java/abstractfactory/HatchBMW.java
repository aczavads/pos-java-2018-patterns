package abstractfactory;

public class HatchBMW implements Hatch {

	@Override
	public String getName() {
		return "Hatch da BMW";
	}

}
