package abstractfactory;

public class HatchVolvo implements Hatch {

	@Override
	public String getName() {
		return "Hatch da Volvo";
	}

}
