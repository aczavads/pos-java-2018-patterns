package abstractfactory;

public class BMWFactory extends CarFactory {

	@Override
	public Car buildCar(CarType type) {
		switch (type) {
		case SEDAN:
			return new SedanBMW();
		case HATCH:
			return new HatchBMW();
		case SUV:
			return new SUVBMW();
		default:
			return null;
		}
	}

}
