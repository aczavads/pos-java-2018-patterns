package abstractfactory;

public class VolvoFactory extends CarFactory {

	@Override
	public Car buildCar(CarType type) {
		switch (type) {
		case SEDAN:
			return new SedanVolvo();
		case HATCH:
			return new HatchVolvo();
		case SUV:
			return new SUVVolvo();
		default:
			return null;
		}
	}

}
