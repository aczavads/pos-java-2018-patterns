package abstractfactory;

public class SedanBMW implements Sedan {

	@Override
	public String getName() {
		return "Sedan da BMW";
	}

}
