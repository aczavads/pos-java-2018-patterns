package abstractfactory;

public class Main {

	public static void main(String[] args) {
		CarFactory carFactory = CarFactory.getFactory(FactoryType.BMW);
		Car car = carFactory.buildCar(CarType.SEDAN);
		System.out.println(car.getName());
		
		CarFactory carFactory2 = CarFactory.getFactory(FactoryType.VOLVO);
		Car car2 = carFactory2.buildCar(CarType.SEDAN);
		System.out.println(car2.getName());
	}
}
