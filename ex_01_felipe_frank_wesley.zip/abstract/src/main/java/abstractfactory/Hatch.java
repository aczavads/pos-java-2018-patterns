package abstractfactory;

public interface Hatch extends Car {

}
