package abstractfactory;

public interface Car {

	public String getName();

}
