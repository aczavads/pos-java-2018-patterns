package abstractfactory;

public enum CarType {
	SEDAN, HATCH, SUV;
}
