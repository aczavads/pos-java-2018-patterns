package abstractfactory;

public enum FactoryType {
	VOLVO, BMW;
}
