package abstractfactory;

public class SedanVolvo implements Sedan {

	@Override
	public String getName() {
		return "Sedan da Volvo";
	}

}
