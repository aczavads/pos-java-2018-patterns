package abstractfactory;

public interface Sedan extends Car {

}
