package abstractfactory;

public interface SUV extends Car {

}
