package abstractfactory;

public class SUVBMW implements SUV {

	@Override
	public String getName() {
		return "SUV da BMW";
	}

}
