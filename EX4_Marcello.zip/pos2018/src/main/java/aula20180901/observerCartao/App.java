package aula20180901.observerCartao;

public class App {
	
	public static void main(String[] args) {
		
		CartaoDeCreditoListener ccL = new CartaoCreditoListenerConsole();
		CartaoDeCredito cc = new CartaoDeCredito();
		cc.registrarListener(ccL);		
		cc.comprarAPrazo(200.00, 2);
		cc.removerListener(ccL);
		cc.comprarAPrazo(300.00, 3);
		
	}
	
	
}
