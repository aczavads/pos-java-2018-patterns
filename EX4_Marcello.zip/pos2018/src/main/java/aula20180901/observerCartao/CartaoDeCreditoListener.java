package aula20180901.observerCartao;

public interface CartaoDeCreditoListener {

	public void compraParceladaRealizada(double valor, int numeroDeParcelas);
}
