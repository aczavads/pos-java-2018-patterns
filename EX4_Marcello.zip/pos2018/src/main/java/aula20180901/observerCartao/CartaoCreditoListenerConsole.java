package aula20180901.observerCartao;

public class CartaoCreditoListenerConsole implements CartaoDeCreditoListener {
	@Override
	public void compraParceladaRealizada(double valor, int numeroDeParcelas) {
		System.out.println("Compra a prazo realizada com sucesso, o valor é: R$" + valor + " Realizado em " + numeroDeParcelas + " Parcelas");
	}

}
