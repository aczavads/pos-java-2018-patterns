package aula20180901.observerCartao;

import java.util.ArrayList;
import java.util.List;

public class CartaoDeCredito {

	private List<CartaoDeCreditoListener> listener = new ArrayList<CartaoDeCreditoListener>();

	public void comprarAVista(Double valor) {
		System.out.println("Compra a Vista");
	}

	public void comprarAPrazo(Double valor, int quantidadeDeParcelas) {
		System.out.println("Compra a Prazo");
		for (CartaoDeCreditoListener cartaoDeCreditoListener : listener) {
			cartaoDeCreditoListener.compraParceladaRealizada(valor, quantidadeDeParcelas);			
		}
	}

	public void registrarListener(CartaoDeCreditoListener ccL) {
		listener.add(ccL);
	}

	public void removerListener(CartaoDeCreditoListener ccL) {
		listener.remove(ccL);
	}

}
