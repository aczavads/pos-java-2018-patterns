package aula20180901.strategy.titulo;

public class Multa implements Encargo
{
	private double taxaDeJuros;

	public Multa(double taxaDeJuros)
	{
		this.taxaDeJuros = taxaDeJuros;
	}
	
	@Override
	public double calcularEncargos(double valorInicial, int diasDeAtraso)
	{
		if (diasDeAtraso <= 0)
			return 0;
		
		return valorInicial * taxaDeJuros;
	}
}
