package aula20180901.strategy.titulo;

import static org.junit.Assert.*;

import org.junit.Test;

public class TesteDoTítulo
{
	@Test
	public void testeDeCálculoDeEncargosDeMulta()
	{
		Multa multa = new Multa(0.1);
		Título título = new Título(100, 5, multa);
		assertEquals(110, título.getValorComEncargos(), 0.001);
	}
	
	@Test
	public void testeDeCálculoDeEncargosDeJuros()
	{
		Juros juros = new Juros(0.1);
		Título título = new Título(100, 5, juros);
		assertEquals(150, título.getValorComEncargos(), 0.001);
	}
	
	@Test
	public void testeDeCálculoDeEncargosSemAtraso()
	{
		Multa multa = new Multa(0.1);
		Título título = new Título(100, 0, multa);
		assertEquals(100, título.getValorComEncargos(), 0.001);
	}
	
	@Test
	public void testeDeCálculoDeEncargosCompostos()
	{
		Multa multa = new Multa(0.1);
		Juros juros = new Juros(0.01);
		EncargoComposto encargoComposto = new EncargoComposto(multa, juros);
		Título título = new Título(100, 10, encargoComposto);
		assertEquals(120, título.getValorComEncargos(), 0.001);
	}
}
