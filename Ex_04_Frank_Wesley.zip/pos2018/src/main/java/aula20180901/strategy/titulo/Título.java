package aula20180901.strategy.titulo;

public class Título
{
	
	private double valor;
	private Encargo encargo;
	private int diasDeAtraso;
	
	public Título(double valor, int diasDeAtraso, Encargo encargo)
	{
		this.valor = valor;
		this.encargo = encargo;
		this.diasDeAtraso = diasDeAtraso;
	}
	
	public double getValorComEncargos()
	{
		return valor + encargo.calcularEncargos(valor, diasDeAtraso);
	}
}
