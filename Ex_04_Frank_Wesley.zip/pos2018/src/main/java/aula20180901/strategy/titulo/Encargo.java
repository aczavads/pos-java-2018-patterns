package aula20180901.strategy.titulo;

public interface Encargo
{
	public double calcularEncargos(double valorInicial, int diasDeAtraso);
}
