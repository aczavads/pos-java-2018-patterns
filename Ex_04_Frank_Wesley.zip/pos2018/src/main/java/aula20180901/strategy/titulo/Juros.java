package aula20180901.strategy.titulo;

public class Juros implements Encargo
{
	private double taxaDeJuros;

	public Juros(double taxaDeJuros)
	{
		this.taxaDeJuros = taxaDeJuros;
	}

	@Override
	public double calcularEncargos(double valorInicial, int diasDeAtraso)
	{
		if (diasDeAtraso <= 0)
			return 0;
		
		return valorInicial * diasDeAtraso * taxaDeJuros;
	}
}
