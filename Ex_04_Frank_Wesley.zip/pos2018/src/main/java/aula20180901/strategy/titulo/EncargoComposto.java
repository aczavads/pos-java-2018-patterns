package aula20180901.strategy.titulo;

import java.util.Arrays;

public class EncargoComposto implements Encargo
{
	private Encargo[] listaDeEncargos;

	public EncargoComposto(Encargo... listaDeEncargos)
	{
		this.listaDeEncargos = listaDeEncargos;
	}
	
	@Override
	public double calcularEncargos(double valorInicial, int diasDeAtraso)
	{
		return Arrays.stream(listaDeEncargos)
					 .mapToDouble(encargo -> encargo.calcularEncargos(valorInicial, diasDeAtraso))
					 .sum();
	}
}
