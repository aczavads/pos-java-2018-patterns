package aula20180901.strategy;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestesComMotor
{
	private static double POTÊNCIA_PADRÃO = 100;
	private static double POTÊNCIA_TURBINADA_COM_1_BAR = 135;
	private static double POTÊNCIA_TURBINADA_COM_2_BAR = 170;
	private static double POTÊNCIA_TURBINADA_COM_3_BAR = 205;
	private static double POTÊNCIA_NITRADO = 150;
	private static double POTÊNCIA_CHIPADO= 120;
	private static double POTÊNCIA_NITRADO_CHIPADO = 170;
	
	@Test
	public void testarPotênciaDoMotorNitradoChipado()
	{
		Motor motor = new Motor();
		motor.chipar();
		motor.nitrar();
		assertEquals(POTÊNCIA_NITRADO_CHIPADO, motor.produzirPotência(), 0.001);
	}
	
	@Test
	public void testarPotênciaDoMotorPadrão()
	{
		Motor motor = new Motor();
		assertEquals(POTÊNCIA_PADRÃO, motor.produzirPotência(), 0.001);
	}
	
	@Test
	public void testarPotênciaDoMotorChipado()
	{
		Motor motor = new Motor();
		motor.chipar();
		assertEquals(POTÊNCIA_CHIPADO, motor.produzirPotência(), 0.001);
	}
	
	@Test
	public void testarPotênciaDoMotorNitrado()
	{
		Motor motor = new Motor();
		motor.nitrar();
		assertEquals(POTÊNCIA_NITRADO, motor.produzirPotência(), 0.001);
	}
	
	@Test
	public void testarPotênciaDoMotorTurbinado1()
	{
		Motor motor = new Motor();
		motor.turbinar(1);
		assertEquals(POTÊNCIA_TURBINADA_COM_1_BAR, motor.produzirPotência(), 0.001);
	}
	
	@Test
	public void testarPotênciaDoMotorTurbinado2()
	{
		Motor motor = new Motor();
		motor.turbinar(2);
		assertEquals(POTÊNCIA_TURBINADA_COM_2_BAR, motor.produzirPotência(), 0.001);
	}
	
	@Test
	public void testarPotênciaDoMotorTurbinado3()
	{
		Motor motor = new Motor();
		motor.turbinar(3);
		assertEquals(POTÊNCIA_TURBINADA_COM_3_BAR, motor.produzirPotência(), 0.001);
	}
}
