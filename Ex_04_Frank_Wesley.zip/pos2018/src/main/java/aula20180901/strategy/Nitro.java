package aula20180901.strategy;

public class Nitro implements ElevadorDePotência
{
	@Override
	public double calcularAdicionalDePotência(double potênciaBase)
	{
		return potênciaBase * 0.5;
	}
}
