package aula20180901.strategy;

import java.util.ArrayList;

public class Motor
{
//	private boolean chipado = false;
//	private boolean nitrado = false;
//	private boolean turbinado = false;
//	private int pressãoDoTurbo = 0;

	private ArrayList<ElevadorDePotência> elevadoresDePotência = new ArrayList<ElevadorDePotência>();
	
	private static final double POTÊNCIA_BASE = 100;
	
	public double produzirPotência()
	{
		double potência = POTÊNCIA_BASE;
		
		for (ElevadorDePotência elevadorDePotência : elevadoresDePotência)
			potência += elevadorDePotência.calcularAdicionalDePotência(POTÊNCIA_BASE);
		
		return potência;
		
//		double potência = POTÊNCIA_BASE;
//		
//		if (chipado)
//			potência += 0.2 * POTÊNCIA_BASE;
//		
//		if (nitrado)
//			potência += 0.5 * POTÊNCIA_BASE;
//		
//		if (turbinado)
//			potência += (pressãoDoTurbo * 0.35) * POTÊNCIA_BASE;
//		
//		return potência;
	}
	
	public void turbinar(int pressãoDoTurbo)
	{
		elevadoresDePotência.add(new Turbo(pressãoDoTurbo));
//		turbinado = true;
//		this.pressãoDoTurbo = pressãoDoTurbo;
	}
	
	public void nitrar()
	{
		elevadoresDePotência.add(new Nitro());
//		nitrado = true;
	}
	
	public void chipar()
	{
		elevadoresDePotência.add(new Chip());
//		chipado = true;
	}
}
