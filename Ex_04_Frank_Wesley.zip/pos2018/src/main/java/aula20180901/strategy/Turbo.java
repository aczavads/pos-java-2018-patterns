package aula20180901.strategy;

public class Turbo implements ElevadorDePotência
{
	private double pressãoDoTurbo;

	public Turbo(double pressãoDoTurbo)
	{
		this.pressãoDoTurbo = pressãoDoTurbo;
	}
	
	@Override
	public double calcularAdicionalDePotência(double potênciaBase)
	{
		return potênciaBase * (pressãoDoTurbo * 0.35);
	}

}
