package aula20180901.strategy;

public interface ElevadorDePotência
{
	public double calcularAdicionalDePotência(double potênciaBase);
}
