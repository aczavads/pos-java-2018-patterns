package aula20180901.strategy;

public class Chip implements ElevadorDePotência
{
	@Override
	public double calcularAdicionalDePotência(double potênciaBase)
	{
		return potênciaBase * 0.2;
	}
}
