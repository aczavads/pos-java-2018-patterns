package aula20180901.observer;

public class Application
{
	public static void main(String[] args)
	{
		CartãoDeCrédito cartão = new CartãoDeCrédito();
		ObservadorDeCartãoDeCrédito observador = new ObservadorDeCartãoDeCrédito(cartão);
		
		System.out.println("Realizando compra à vista...");
		cartão.compraÀVista(400);
		System.out.println("Realizando compra à prazo...");
		cartão.compraÀPrazo(400, 6);
	}
}
