package aula20180901.observer;

import java.util.Observable;
import java.util.Observer;

public class ObservadorDeCartãoDeCrédito implements Observer
{	
	Observable cartãoDeCrédito;
	
	public ObservadorDeCartãoDeCrédito(Observable cartãoDeCrédito)
	{
		this.cartãoDeCrédito = cartãoDeCrédito;
		this.cartãoDeCrédito.addObserver(this);
	}
	
	@Override
	public void update(Observable arg0, Object arg1)
	{
		System.out.println("Compra parcelada realizada");
	}
}
