package aula20180901.observer;

import java.util.Observable;

public class CartãoDeCrédito extends Observable
{	
	public void compraÀVista(double valor)
	{	
	}
	
	public void compraÀPrazo(double valor, int parcelas)
	{
		setChanged();
		notifyObservers();
	}
}
