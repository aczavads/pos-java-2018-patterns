package aula20180825.factory.cars;

public class App {
	
	public static void main(String[] args) {
		
		Montadora m = Montadora.criarMontadora();
		Veiculo hatch = m.fabricar("hatch");
		Veiculo sedan = m.fabricar("sedan");
		
		hatch.ligar();
		hatch.desligar();
		
		sedan.ligar();
		sedan.desligar();
		
	}

}
