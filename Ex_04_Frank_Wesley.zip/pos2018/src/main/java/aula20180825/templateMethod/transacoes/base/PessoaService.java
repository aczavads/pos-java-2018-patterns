package aula20180825.templateMethod.transacoes.base;


public class PessoaService extends Service {
	
	@Override
	protected void executarExclusãoPeloId(int id) {
		System.out.println("delete from pessoa where id="+id);
	}


}
