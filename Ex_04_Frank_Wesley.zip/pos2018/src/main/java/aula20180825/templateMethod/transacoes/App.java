package aula20180825.templateMethod.transacoes;

import aula20180825.templateMethod.transacoes.base.PessoaService;

public class App {
	
	public static void main(String[] args) {
		
		PessoaService service = new PessoaService();
		
		service.excluirPeloId(55454);
		
	}
	
	

}
