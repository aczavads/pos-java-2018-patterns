package associações;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
	private int número;
	private List<ItemPedido> itens = new ArrayList<Pedido.ItemPedido>();
		
	public Pedido(int número) {
		this.número = número;
	}
	
	public int getNúmero() {
		return número;
	}
	
	public void setNúmero(int número) {
		this.número = número;
	}
	
	//+ adicionarItem(produto : Produto, quantidade : double, preço : double) : ItemPedido
	public ItemPedido adicionarItem(Produto produto, double quantidade, double preço) {
		ItemPedido novo = new ItemPedido(produto, quantidade, preço);
		itens.add(novo);
		return novo;
	}
	
	
	public static class ItemPedido {
		private Produto produto;
		private double quantidade;
		private double preço;
		
		private ItemPedido(Produto produto, double quantidade, double preço) {
			this.produto = produto;
			this.quantidade = quantidade;
			this.preço = preço;
		}
		public Produto getProduto() {
			return produto;
		}
		public void setProduto(Produto produto) {
			this.produto = produto;
		}
		public double getQuantidade() {
			return quantidade;
		}
		public void setQuantidade(double quantidade) {
			this.quantidade = quantidade;
		}
		public double getPreço() {
			return preço;
		}
		public void setPreço(double preço) {
			this.preço = preço;
		}
	}
}



