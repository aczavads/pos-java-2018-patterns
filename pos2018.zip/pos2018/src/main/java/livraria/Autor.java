package livraria;

public class Autor {
	//- nome : String
	private String nome;

}
