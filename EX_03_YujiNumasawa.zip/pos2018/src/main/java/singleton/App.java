package singleton;

public class App {
	
	public static void main(String[] args) {
		Universo[] meusUniversos = new Universo[10];
		for (int i = 0; i < meusUniversos.length; i++) {
			//meusUniversos[i] = new Universo();
			meusUniversos[i] = Universo.getUniverso(); 
		}
		
		for (Universo universo : meusUniversos) {
			System.out.println(universo.toString());
		}
	}
}
