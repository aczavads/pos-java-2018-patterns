package aula20180825.factory.loggerReflexivo;

public abstract class LoggerFactory {

	public static Logger createLogger(String nomeDaClasseDoLogger) {
		
		try {
			//Class classeDoLogger = Class.forName("aula20180825.factory.loggerReflexivo.ConsoleLogger");
			Class classeDoLogger = Class.forName(nomeDaClasseDoLogger);
			Logger logger = (Logger) classeDoLogger.newInstance();
			return logger;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new NullLogger();
		
	}

}
