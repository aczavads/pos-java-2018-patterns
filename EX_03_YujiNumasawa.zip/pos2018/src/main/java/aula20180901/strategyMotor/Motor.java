package aula20180901.strategyMotor;

import java.util.List;
import java.util.ArrayList;

public class Motor {
	private List<Veneno> venenos = new ArrayList<Veneno>();
	public double produzirPotencia() {
		double potenciaBase = 100;
		double potenciaFinal = potenciaBase;
		
		for (Veneno veneno: venenos){
			potenciaFinal += veneno.elevarPotencia(potenciaBase);
		}
		return potenciaFinal;
	}

	public void turbinar() {
		this.turbinar(1.00);
	}
	
	public void turbinar(double pressao) {		
		this.venenos.add(new Turbo(pressao));
	}

	public void chipar() {
		this.venenos.add(new Chip());
	}

	public void nitrar() {
		this.venenos.add(new Nitro());
	}

}
